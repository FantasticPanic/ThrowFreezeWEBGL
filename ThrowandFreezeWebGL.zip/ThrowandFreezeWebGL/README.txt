Open the index html file with "Microsoft Edge" if possible
The build currently won't work on Google Chrome.

Press the Spacebar to throw an ice projectile.